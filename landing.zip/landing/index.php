<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="preconnect" href="https://fonts.googleapis.com"/>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css"/>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css"/>
    <link rel="stylesheet" href="css/main.css"/>
</head>
<body>
    <header>
        <div class="container">
        <div class="headerSection">  
        <img src="img/logo.svg" alt="Logo"/> 
        <button class="getStartedbtn">Get Started</button>    
    </div> 
        </div>
    </header>

    <section class="bannerPnl">
        <div class="bannerBg">
        </div>
        <div class="container">
            <div class="bannerSection">
                <div class="bannerSectionContent">
                    <p class="smalltext">BE SURE</p>  
                    <h1>Your Success Is In Our Hands</h1>
                    <p>Agency with 12 years of history, 15 employees, Fortune 5000 clients and proven results.</p>
                    <a href="#" class="learnmoreBtn">Learn More</a>
                </div>
            </div>
        </div>
    </section>
   
    <section class="servicesPnl">
        <div class="container">
            <div class="servicesSection">
                <div class="servicesBox">
                    <div class="servicesDecor"></div>
                    <div class="servicesIcon">
                        <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
                    </div>
                    <div class="servicesTitle">
                        <h2>SEO Consultancy</h2>
                    </div>
                    <div class="servicesText">
                        <p>Dolor enim dolor labore velit nulla sit exercitation proident esse culpa commodo n irure esse velit commodo.</p>
                    </div>
                </div>

                <div class="servicesBox">
                    <div class="servicesDecor"></div>
                    <div class="servicesIcon">
                        <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
                    </div>
                    <div class="servicesTitle">
                        <h2>SEO Consultancy</h2>
                    </div>
                    <div class="servicesText">
                        <p>Dolor enim dolor labore velit nulla sit exercitation proident esse culpa commodo n irure esse velit commodo.</p>
                    </div>
                </div>

                <div class="servicesBox">
                    <div class="servicesDecor"></div>
                    <div class="servicesIcon">
                        <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
                    </div>
                    <div class="servicesTitle">
                        <h2>SEO Consultancy</h2>
                    </div>
                    <div class="servicesText">
                        <p>Dolor enim dolor labore velit nulla sit exercitation proident esse culpa commodo n irure esse velit commodo.</p>
                    </div>
                </div>

                <div class="servicesBox">
                    <div class="servicesDecor"></div>
                    <div class="servicesIcon">
                        <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
                    </div>
                    <div class="servicesTitle">
                        <h2>SEO Consultancy</h2>
                    </div>
                    <div class="servicesText">
                        <p>Dolor enim dolor labore velit nulla sit exercitation proident esse culpa commodo n irure esse velit commodo.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="aboutSection">
        <div class="container">
            <div class="aboutpnl">
                <div class="aboutImg">
                    <img src="img/about.svg" alt="Company About"/>
                </div>
                <div class="aboutContent">
                    <p class="smalltext">THE HISTORY</p>
                    <h3 class="primaryHeading">Our Way To Succesful Future</h3>
                    <p class="primaryText">Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proident velit commodo. Est non officia proident esse culpa commodo nulla Lorem do enderit esse do.</p>
                    <a href="#" class="learnmoreBtn">Learn More</a>
                </div>
            </div>
        </div>
    </section>

    <section class="countdown">
    <div class="container">
        <div class="countdownFlex">
            <div class="countdownBox">
                <h4>$35K</h4>
                <p>CLIENTS REVENUE</p>
            </div>
            <div class="countdownBox">
                <h4>16K</h4>
                <p>LEADS FOR CLIENTS</p>
            </div>
            <div class="countdownBox">
                <h4>6.7k</h4>
                <p>PHONE CALLS</p>
            </div>
            <div class="countdownBox">
                <h4>254k</h4>
                <p>SUCCESSFUL PROJECTS</p>
            </div>
        </div>
    </div>
    </section>

    <section class="whatyouwill">
        <div class="container">
            <div class="whatyouwillHeading textCenter">
                <p class="smalltext">What We Do</p>
                <h4 class="primaryHeading">What You Will Get With Us</h4>
                <p class="primaryText">Dolor duis voluptate enim exercitation consequat ex.</p>
            </div>
            <div class="slick-wrapper">
  <div id="whatyouWillSlider">
		<div class="slide-item">
            <div class="sliderImg">
            <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
            </div>
            <div class="slideContent">
                <h4>Research & Analysis 01</h4>
                <p>Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proid.</p>
                <a href="#"><a href="#"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"/>	</g></g></svg></a>
            </div>
        </div>

        <div class="slide-item">
            <div class="sliderImg">
            <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
            </div>
            <div class="slideContent">
                <h4>Research & Analysis 02</h4>
                <p>Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proid.</p>
                <a href="#"><a href="#"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"/>	</g></g></svg></a>
            </div>
        </div>

        <div class="slide-item">
            <div class="sliderImg">
            <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
            </div>
            <div class="slideContent">
                <h4>Research & Analysis 03</h4>
                <p>Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proid.</p>
                <a href="#"><a href="#"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"/>	</g></g></svg></a>
            </div>
        </div>

        <div class="slide-item">
            <div class="sliderImg">
            <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
            </div>
            <div class="slideContent">
                <h4>Research & Analysis 04</h4>
                <p>Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proid.</p>
                <a href="#"><a href="#"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"/>	</g></g></svg></a>
            </div>
        </div>

        <div class="slide-item">
            <div class="sliderImg">
            <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
            </div>
            <div class="slideContent">
                <h4>Research & Analysis 05</h4>
                <p>Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proid.</p>
                <a href="#"><a href="#"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"/>	</g></g></svg></a>
            </div>
        </div>

        <div class="slide-item">
            <div class="sliderImg">
            <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
            </div>
            <div class="slideContent">
                <h4>Research & Analysis 06</h4>
                <p>Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proid.</p>
                <a href="#"><a href="#"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"/>	</g></g></svg></a>
            </div>
        </div>

        <div class="slide-item">
            <div class="sliderImg">
            <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
            </div>
            <div class="slideContent">
                <h4>Research & Analysis 07</h4>
                <p>Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proid.</p>
                <a href="#"><a href="#"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"/>	</g></g></svg></a>
            </div>
        </div>

        <div class="slide-item">
            <div class="sliderImg">
            <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
            </div>
            <div class="slideContent">
                <h4>Research & Analysis 08</h4>
                <p>Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proid.</p>
                <a href="#"><a href="#"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"/>	</g></g></svg></a>
            </div>
        </div>

        <div class="slide-item">
            <div class="sliderImg">
            <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
            </div>
            <div class="slideContent">
                <h4>Research & Analysis 09</h4>
                <p>Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proid.</p>
                <a href="#"><a href="#"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"/>	</g></g></svg></a>
            </div>
        </div>

        <div class="slide-item">
            <div class="sliderImg">
            <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
            </div>
            <div class="slideContent">
                <h4>Research & Analysis 10</h4>
                <p>Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proid.</p>
                <a href="#"><a href="#"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"/>	</g></g></svg></a>
            </div>
        </div>
		
	</div>
</div>
        </div>
    </section>

    <section class="testimonialsPnl">
        <div class="bgTestimonials"></div>
        <div class="container">
            <div class="testimonialFlex">
                <div class="testimonialsBox">
                    <img src="img/testimonials.svg" alt="Client Testimonials"/>
                </div>
                <div class="testimonialsBox">
                <p class="smalltext">THEY SAY</p>    
                <h4 class="primaryHeading">Testimonials</h4>
                <div class="slick-wrapper">
  <div id="testimonialsSlide">
		<div class="slide-item">
            <div class="testimoniallogo">
            <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
            </div>
            <div class="testimonialsContent">
                <p>Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proid.</p>
                <h4>Research & Analysis 01</h4>
            </div>
        </div>

        <div class="slide-item">
            <div class="testimoniallogo">
            <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
            </div>
            <div class="testimonialsContent">
                <p>Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proid.</p>
                <h4>Research & Analysis 01</h4>
            </div>
        </div>

        <div class="slide-item">
            <div class="testimoniallogo">
            <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
            </div>
            <div class="testimonialsContent">
                <p>Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proid.</p>
                <h4>Research & Analysis 01</h4>
            </div>
        </div>

        <div class="slide-item">
            <div class="testimoniallogo">
            <img src="img/exellence-1.svg" alt="SEO Consultancy"/>
            </div>
            <div class="testimonialsContent">
                <p>Dolor duis voluptate enim exercitation consequat ex. Voluptate in sunt commodo aute do. Dolor enim dolor labore velit nulla sit exercitation irure esse proid.</p>
                <h4>Research & Analysis 01</h4>
            </div>
        </div>

       

        
		
	</div>
</div>
                </div>
            </div>
        </div>
    </section>
    <section class="clientPnl">
        <div class="container">
        <div id="clientSlide">
		<div class="slide-item">
            <div class="testimoniallogo">
            <img src="img/client/logo-1.svg" alt="Client Logo"/>
            </div>
        </div>

        <div class="slide-item">
            <div class="testimoniallogo">
            <img src="img/client/logo-2.svg" alt="Client Logo"/>
            </div>
        </div>

        <div class="slide-item">
            <div class="testimoniallogo">
            <img src="img/client/logo-3.svg" alt="Client Logo"/>
            </div>
        </div>

        <div class="slide-item">
            <div class="testimoniallogo">
            <img src="img/client/logo-4.svg" alt="Client Logo"/>
            </div>
        </div>

        <div class="slide-item">
            <div class="testimoniallogo">
            <img src="img/client/logo-5.svg" alt="Client Logo"/>
            </div>
        </div>

        <div class="slide-item">
            <div class="testimoniallogo">
            <img src="img/client/logo-5.svg" alt="Client Logo"/>
            </div>
        </div>

        

       

        
		
	</div>
        </div>
    </section>

    <section class="mailMilestone">
    <div class="bgmilestone"></div>
        <div class="container">
            <div class="mainMilestoneFlex">
                <div class="mainMilestoneBox milestoneOne">
                    <img src="img/milestone/step-1.svg"/>
                    <h5>Planning</h5>
                </div>
                <div class="mainMilestoneBox milestoneTwo">
                    <img src="img/milestone/step-2.svg"/>
                    <h5>Research</h5>
                </div>
                <div class="mainMilestoneBox milestoneThree">
                    <img src="img/milestone/step-3.svg"/>
                    <h5>Optimization</h5>
                </div>
                <div class="mainMilestoneBox milestoneFour">
                    <img src="img/milestone/step-4.svg"/>
                    <h5>Results</h5>
                </div>
            </div>
        </div>
    </section>

    <section class="blogPnl">
        <div class="container">
        <div class="blogHeader textCenter">
            <p class="smalltext">NEWS</p>
            <h5 class="primaryHeading">Read Our Blog</h5>
            <p class="primaryText ">Dolor duis voluptate enim exercitation consequat ex.</p>
        </div>
        <div id="blogSlide">
		<div class="slide-item">
            <div class="blogContent">
            <h5>Dolor Duis Voluptate Enim Exercitation Consequat Ex. Voluptate In Sunt</h5>
            <p>Pariatur cupidatat Lorem irure nisi. Velit qui irure consectetur do cupi roident id est ex sunt nostrud nisi mine consectetur do cupi roident id est ex sunt nostrud nisi minim ut. Cupidatat velit dolore consectetur deserunt laboris magna eiusmod aliquip consectetur commodo in eiusmod aliqua cupidatat.</p>
            <a href="#" tabindex="0"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"></polygon>	</g></g></svg></a>    
        </div>
        </div>

        <div class="slide-item">
            <div class="blogContent">
            <h5>Dolor Duis Voluptate Enim Exercitation Consequat Ex. Voluptate In Sunt</h5>
            <p>Pariatur cupidatat Lorem irure nisi. Velit qui irure consectetur do cupi roident id est ex sunt nostrud nisi mine consectetur do cupi roident id est ex sunt nostrud nisi minim ut. Cupidatat velit dolore consectetur deserunt laboris magna eiusmod aliquip consectetur commodo in eiusmod aliqua cupidatat.</p>
            <a href="#" tabindex="0"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"></polygon>	</g></g></svg></a>    
        </div>
        </div>

        <div class="slide-item">
            <div class="blogContent">
            <h5>Dolor Duis Voluptate Enim Exercitation Consequat Ex. Voluptate In Sunt</h5>
            <p>Pariatur cupidatat Lorem irure nisi. Velit qui irure consectetur do cupi roident id est ex sunt nostrud nisi mine consectetur do cupi roident id est ex sunt nostrud nisi minim ut. Cupidatat velit dolore consectetur deserunt laboris magna eiusmod aliquip consectetur commodo in eiusmod aliqua cupidatat.</p>
            <a href="#" tabindex="0"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"></polygon>	</g></g></svg></a>    
        </div>
        </div>

        <div class="slide-item">
            <div class="blogContent">
            <h5>Dolor Duis Voluptate Enim Exercitation Consequat Ex. Voluptate In Sunt</h5>
            <p>Pariatur cupidatat Lorem irure nisi. Velit qui irure consectetur do cupi roident id est ex sunt nostrud nisi mine consectetur do cupi roident id est ex sunt nostrud nisi minim ut. Cupidatat velit dolore consectetur deserunt laboris magna eiusmod aliquip consectetur commodo in eiusmod aliqua cupidatat.</p>
            <a href="#" tabindex="0"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"></polygon>	</g></g></svg></a>    
        </div>
        </div>

        <div class="slide-item">
            <div class="blogContent">
            <h5>Dolor Duis Voluptate Enim Exercitation Consequat Ex. Voluptate In Sunt</h5>
            <p>Pariatur cupidatat Lorem irure nisi. Velit qui irure consectetur do cupi roident id est ex sunt nostrud nisi mine consectetur do cupi roident id est ex sunt nostrud nisi minim ut. Cupidatat velit dolore consectetur deserunt laboris magna eiusmod aliquip consectetur commodo in eiusmod aliqua cupidatat.</p>
            <a href="#" tabindex="0"><svg height="25px" width="25px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 227.096 227.096" xml:space="preserve"><g>	<g><polygon style="fill:#fb5472;" points="152.835,39.285 146.933,45.183 211.113,109.373 0,109.373 0,117.723 211.124,117.723 
			146.933,181.902 152.835,187.811 227.096,113.55 		"></polygon>	</g></g></svg></a>    
        </div>
        </div>
	</div> 
        </div>
    </section>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
    <script type="text/javascript" src="js/main.js"></script>
</body>
</html>